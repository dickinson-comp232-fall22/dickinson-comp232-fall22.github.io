package streamdemo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * Demonstration of various methods for creating streams.
 * 
 * NOTE: You will need a file called 'words.txt' in the 'data' directory
 * before running this.
 * 
 * @author jmac
 *
 */
public class CreateStream {

	// The following three methods print out the contents of a stream. The
	// weird "::" notation will be explained later.
	private static <T> void printStream(Stream<T> s) {
		s.forEach(System.out::println);
	}

	private static void printStream(DoubleStream s) {
		s.forEach(System.out::println);
	}

	private static void printStream(IntStream s) {
		s.forEach(System.out::println);
	}

	public static void main(String[] args) throws IOException {
		// Approach 1: Create directly from an array via Stream.of()
		String[] array = { "bat", "cat", "bird", "mad", "catch", "ditch" };
		Stream<String> stream1 = Stream.of(array);
//		printStream(stream1);

		// Approach 2: Create directly from multiple arguments via
		// Stream.of()
		Stream<String> stream2 = Stream.of("bat", "cat", "bird", "mad",
				"catch", "ditch");
//		printStream(stream2);

		// Approach 3: Convert any Java Collection using the collection's
		// stream() method
		List<String> list = Arrays.asList("bat", "cat", "bird", "mad",
				"catch", "ditch");
		Stream<String> stream3 = list.stream();
//		printStream(stream3);

		// Approach 4: Stream from a file using Files.lines
		Stream<String> stream4 = Files.lines(Paths.get("data/words.txt"));
		printStream(stream4);

		Stream<Double> doubleObjects = Stream.of(23.4, 69.7, -25.88,
				31.3363);
		DoubleStream doublePrimitives = DoubleStream.of(23.4, 69.7, -25.88,
				31.3363);
//		printStream(doublePrimitives);

		// Approach 5: Use range() or rangeClosed()
		IntStream range1 = IntStream.range(5, 10); // 5,6,7,8,9
		IntStream range2 = IntStream.rangeClosed(5, 10); // 5,6,7,8,9,10 
//		printStream(range2);
	}

}
