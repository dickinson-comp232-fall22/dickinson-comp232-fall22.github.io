package streamdemo;

import java.util.stream.DoubleStream;

/**
 * Demonstrates how to sum the elements of a numeric stream.
 * 
 * @author jmac
 *
 */
public class Sum {

	public static void main(String[] args) {
		DoubleStream stream = DoubleStream.of(1.5, 2.4, -0.1);
		double total = stream.sum();
		System.out.println("Total is " + total);
	}

}
