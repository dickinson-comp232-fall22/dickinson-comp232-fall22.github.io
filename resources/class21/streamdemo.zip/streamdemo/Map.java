package streamdemo;

import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * Demonstrates the map() method of the Stream interface.
 * 
 * @author jmac
 *
 */
public class Map {

	public static void main(String[] args) {
		Stream<String> stream = Stream.of("apple", "banana", "bagel");
		stream.map(word -> word.toUpperCase() + "***")
				.forEach(System.out::print);

		System.out.println();
		
		// Compute 1^2 + 2^2 + 3^2 + ... + 100^2
		IntStream intStream = IntStream.rangeClosed(1, 100);
		int sumOfSquares = intStream.map(x -> x * x)
				.sum();
		System.out.println(sumOfSquares);
	}

}
