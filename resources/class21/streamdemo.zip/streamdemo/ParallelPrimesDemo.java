package streamdemo;

import java.util.Random;
import java.util.stream.IntStream;

/**
 * This class provides a demonstration of the speed-up that can be obtained
 * by using parallel streams rather than sequential streams.
 * 
 * @author John MacCormick
 * @author Dickinson College
 * @version August 2021
 *
 */
public class ParallelPrimesDemo {

	// A deliberately inefficient way of determining whether an integer
	// n>=2 is prime. We just want to perform a computationally intensive
	// task to demonstrate the benefits of parallelism.
	private static boolean isPrime(int n) {
		for (int i = 2; i < n; i++) {
			if (n % i == 0) {
				return false;
			}
		}
		return true;
	}

	public static void main(String[] args) {
		// Step 1. Create a large array of random integers. We ensure that
		// each integer is greater than or equal to 2, so that it makes
		// sense to ask whether the integer is prime.
		Random random = new Random();
		final int numValues = 2000000;
		final int maxValue = 10000;
		int[] values = new int[numValues];
		for (int i = 0; i < values.length; i++) {
			values[i] = 2 + random.nextInt(maxValue - 2);
		}

		// We repeat the remaining steps several times so that we can check
		// if the timing results are reliable.
		int numRepetitions = 5;
		for (int repetition = 0; repetition < numRepetitions; repetition++) {

			// Step 2. Use a sequential stream to determine how many of the
			// random integers are prime, and record the time taken.
			long numPrimes1, numPrimes2;
			long startTime, endTime;
			startTime = System.nanoTime();
			numPrimes1 = IntStream.of(values).sequential()
					.filter(n -> isPrime(n)).count();
			endTime = System.nanoTime();
			long sequentialDuration = (endTime - startTime) / 1000000; // milliseconds

			// Step 3. The same as the previous step, but with a parallel
			// stream.
			startTime = System.nanoTime();
			numPrimes2 = IntStream.of(values).parallel()
					.filter(n -> isPrime(n)).count();
			endTime = System.nanoTime();
			long parallelDuration = (endTime - startTime) / 1000000; // milliseconds

			// The answers had better be the same!
			assert numPrimes1 == numPrimes2;

			// Step 4. Print the timing results.
			double speedup = (double) sequentialDuration
					/ parallelDuration;
			System.out.format(
					"sequential %dms, parallel %dms, speedup factor %2.2f\n",
					sequentialDuration, parallelDuration, speedup);
		}
	}
}
