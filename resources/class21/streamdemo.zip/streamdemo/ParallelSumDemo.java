package streamdemo;

import java.util.SplittableRandom;
import java.util.stream.DoubleStream;

/**
 * Demonstrates the use of a parallel stream to add a sequence of random
 * numbers, comparing the computation time to the use of a sequential
 * stream. On computers with multiple CPU cores, the parallel
 * implementation should be faster.
 * 
 * @author jmac
 *
 */
public class ParallelSumDemo {
	SplittableRandom splittableRandom;

	public ParallelSumDemo() {
		splittableRandom = new SplittableRandom();
	}

	double doTimedExperiment(boolean isParallel, long numRandoms) {
		DoubleStream stream;
		if (isParallel) {
			stream = splittableRandom.doubles().parallel();
			System.out.print("parellel: ");
		} else {
			stream = splittableRandom.doubles().sequential();
			System.out.print("sequential: ");
		}

		double sum;
		long startTime = System.nanoTime();
		// sum the first numRandoms elements of the random sequence.
		sum = stream.limit(numRandoms).sum();
		long endTime = System.nanoTime();
		long duration = (endTime - startTime);
		System.out.println("duration " + duration / 1000000L + " ms");
		// return the average value of numbers in the sequence.
		return sum / numRandoms;
	}

	public static void main(String[] args) {
		ParallelSumDemo p = new ParallelSumDemo();
		long numRandoms = 100000000;
		p.doTimedExperiment(true, numRandoms);
		p.doTimedExperiment(false, numRandoms);
		p.doTimedExperiment(true, numRandoms);
		p.doTimedExperiment(false, numRandoms);
		p.doTimedExperiment(true, numRandoms);
		p.doTimedExperiment(false, numRandoms);
	}

}
