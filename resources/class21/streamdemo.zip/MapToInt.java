package streamdemo;

import java.util.stream.Stream;

/**
 * Demonstrates the mapToInt() method of the Stream interface.
 * 
 * @author jmac
 *
 */
public class MapToInt {
	public static void main(String[] args) {
		Stream<String> stream = Stream.of("apple", "banana", "bagel");
		stream.mapToInt(word -> word.indexOf('e'))
				.forEach(System.out::println);
	}
}
