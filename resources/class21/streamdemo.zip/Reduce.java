package streamdemo;

import java.util.function.BinaryOperator;
import java.util.stream.Stream;

/**
 * Demonstrate the reduce() method from the Stream interface.
 * 
 * @author jmac
 *
 */
public class Reduce {
	// Below we give three different ways of tackling a simple task.
	// The simple task is to concatenate the first letter from each element
	// of an array of strings and print out the result.

	////////////////////////////////////////////////
	// 1. Simple approach without using streams
	////////////////////////////////////////////////
	public static void concatFirstLetters1() {
		String[] array = { "apple", "banana", "bagel" };
		String initialValue = "";
		String resultSoFar = initialValue;
		for (String newElement : array) {
			resultSoFar = resultSoFar + newElement.charAt(0);
		}
		System.out.println(resultSoFar);
	}

	////////////////////////////////////////////////
	// 2. Still without using streams, but refactored
	// to use an accumulate() method
	////////////////////////////////////////////////
	public static String accumulate(String resultSoFar,
			String newElement) {
		return resultSoFar + newElement.charAt(0);
	}

	public static void concatFirstLetters2() {
		String[] array2 = { "apple", "banana", "bagel" };
		String initialValue = "";
		String resultSoFar = initialValue;
		for (String newElement : array2) {
			resultSoFar = accumulate(resultSoFar, newElement);
		}
		System.out.println(resultSoFar);

	}

	////////////////////////////////////////////////
	// 3. Now using streams, via the reduce() method.
	////////////////////////////////////////////////
	public static void concatFirstLetters3() {
		Stream<String> stream = Stream.of("apple", "banana", "bagel");
		String firstLetters = stream.reduce("", // first parameter is the
												// initial value, an empty
												// String
				(resultSoFar, newElement) -> resultSoFar
						+ newElement.charAt(0)
		// second parameter (above) is the ‘accumulate’ function,
		// written as a lambda expression with two parameters
		);
		System.out.println(firstLetters);
	}

	public static void concatFirstLetters4() {
		Stream<String> stream = Stream.of("apple", "banana", "bagel");
		// refer to the accumulator via the "::" notation
		String firstLetters = stream.reduce("", Reduce::accumulate);
		System.out.println(firstLetters);
	}

	public static void concatFirstLetters5() {
		Stream<String> stream = Stream.of("apple", "banana", "bagel");
		// declare the accumulator using a lambda expression
		BinaryOperator<String> acc = (resultSoFar,
				newElement) -> resultSoFar + newElement.charAt(0);
		String firstLetters = stream.reduce("", acc);
		System.out.println(firstLetters);
	}

	public static void main(String[] args) {
		concatFirstLetters1();
		concatFirstLetters2();
		concatFirstLetters3();
		concatFirstLetters4();
		concatFirstLetters5();
	}

}
