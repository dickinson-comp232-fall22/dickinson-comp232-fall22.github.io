package streamdemo;

import java.util.stream.Stream;

public class Filter {
	// The following method prints out the contents of a stream. The
	// weird "::" notation will be explained later.
	private static <T> void printStream(Stream<T> s) {
		s.forEach(System.out::println);
	}

	public static void main(String[] args) {
		Stream<String> stream = Stream.of("bat", "cat", "bird", "mad",
				"catch", "ditch");
		Stream<String> newStream = stream
				.filter(word -> word.startsWith("ca"));
		printStream(newStream);

		// Here is a more idiomatic way of achieving the same thing.
//		stream = Stream.of("bat", "cat", "bird", "mad", "catch", "ditch");
//		stream.filter(word -> word.startsWith("ca"))
//				.forEach(System.out::println);

	}
}
