package streamdemo;

import java.util.stream.Stream;

/**
 * Demonstrates how to count the elements in a stream.
 * 
 * @author jmac
 *
 */
public class Count {

	public static void main(String[] args) {
		Stream<String> stream = Stream.of("bat", "cat", "bird");
		long numElements = stream.count();
		System.out.println(numElements);

	}

}
