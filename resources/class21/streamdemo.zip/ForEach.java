package streamdemo;

import java.util.stream.Stream;

/**
 * Demonstrates how to use the forEach() stream method for printing out
 * streams. Remember, use the forEach() method only for producing output,
 * not for doing computations!
 * 
 * @author jmac
 *
 */
public class ForEach {

	public static void main(String[] args) {
		Stream<String> stream = Stream.of("apple", "banana", "bagel");
		stream.forEach(System.out::println);
		
		// equivalently, using a lambda expression:
//		stream = Stream.of("apple", "banana", "bagel");
//		stream.forEach(word -> System.out.println(word));
	}

}
