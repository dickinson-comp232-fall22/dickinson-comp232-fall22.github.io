package streamdemo;

import java.util.SplittableRandom;
import java.util.stream.DoubleStream;

/**
 * Demonstrates the use of a parallel stream to add a sequence of random
 * numbers, comparing the computation time to the use of a sequential
 * stream. On computers with multiple CPU cores, the parallel
 * implementation should be faster.
 * 
 * @author jmac
 *
 */
public class ParallelSumDemo {
	// This is a random number generator suitable for use in parallel
	// computations.
	// See the documentation in java.util.
	SplittableRandom splittableRandom;

	public ParallelSumDemo() {
		splittableRandom = new SplittableRandom();
	}

	/**
	 * Performs a timed experiment that adds up the elements in a stream of
	 * random numbers, either in parallel mode or sequential mode.
	 * 
	 * @param isParallel   True if the experiment should be in parallel
	 *                     mode, false if it should be in sequential mode.
	 * @param numRandoms   The number of random numbers to be summed during
	 *                     the experiment
	 * @param printResults True if we should print out the time taken,
	 *                     false otherwise
	 * @return The time taken for the experiment, measured in nanoseconds.
	 */
	long doTimedExperiment(boolean isParallel, long numRandoms,
			boolean printResults) {
		DoubleStream stream;
		String description = "";
		if (isParallel) {
			stream = splittableRandom.doubles().parallel();
			description = "parellel";
		} else {
			stream = splittableRandom.doubles().sequential();
			description = "sequential";
		}

		double sum;
		long startTime = System.nanoTime();
		// sum the first numRandoms elements of the random sequence.
		sum = stream.limit(numRandoms).sum();
		long endTime = System.nanoTime();
		long duration = (endTime - startTime);
		if (printResults) {
			System.out.println(description + ": duration "
					+ duration / 1000000L + " ms");
		}
		return duration;
	}

	public static void main(String[] args) {
		ParallelSumDemo p = new ParallelSumDemo();
		long numRandoms = 100000000;
		int repetitions = 3;

		// Do a warm-up so that later results will be more typical.
		p.doTimedExperiment(true, numRandoms, false);
		p.doTimedExperiment(false, numRandoms, false);

		// Now do the timed experiments
		for (int i = 0; i < repetitions; i++) {
			long parallelTime = p.doTimedExperiment(true, numRandoms,
					true);
			long sequentialTime = p.doTimedExperiment(false, numRandoms,
					true);
			double speedup = (double) sequentialTime / parallelTime;
			System.out.format("speedup %.2f\n\n", speedup);
		}
	}

}
