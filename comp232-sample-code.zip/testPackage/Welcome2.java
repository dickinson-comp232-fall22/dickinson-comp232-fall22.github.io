package testPackage;

public class Welcome2 {
	public static void main(String[] args) {
		System.out.println("Just testing something");
	}
}
